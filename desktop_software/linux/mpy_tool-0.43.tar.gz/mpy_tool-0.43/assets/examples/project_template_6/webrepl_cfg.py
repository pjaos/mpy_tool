# The password must be 4 to 9 characters long
# This file must have a new line after the password.
PASS = '12345678'
