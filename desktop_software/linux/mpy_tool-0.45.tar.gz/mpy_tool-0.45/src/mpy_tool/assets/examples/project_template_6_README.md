# Example Project 6

This example has all the functionality of example 5 plus the ability to connect via a web browser
to a web repl prompt (via WiFi interface).

To connect to the web repl prompt enter 'http://MCUIPADDRESS:8266 (replace MCUIPADDRESS with the IP address of your MCU) into the address bar of your web browser.

When you connect you will need to enter the password. The default webrepl password is 12345678.


You may change this password by editing the webrepl_cfg.py file.

E.G

```
PASS = '12345678'

```

Note that this file must have a line feed character at the end of the line.
