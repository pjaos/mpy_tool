This was built from the master branch as the v1.24-release does not currently (16 Aug 2025) support the RPi Pico 2 W and no further official releases exist at the moment.
