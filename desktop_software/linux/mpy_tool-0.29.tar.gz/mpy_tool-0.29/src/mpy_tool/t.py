from nicegui import ui

last_value = 'abcd'  # load from disk initially

def open_dialog():
    global last_value

    def on_ok():
        global last_value
        last_value = text.value  # save to persistent state
        ui.notify(f'You entered: {text.value}')
        dialog.close()

    with ui.dialog() as dialog, ui.card():
        text = ui.input('Name', value=last_value)
        with ui.row():
            ui.button('OK', on_click=on_ok)
            ui.button('Cancel', on_click=dialog.close)

    dialog.open()

ui.button('Open dialog', on_click=open_dialog)

ui.run()