#!/usr/bin/env python3

import os

from   nicegui import ui

# PJA for local_file_save
import platform
from pathlib import Path

class local_file_save(ui.dialog):
    """@brief Allows the user to save a file to local storage.
       This is is a change to https://github.com/zauberzeug/nicegui/blob/main/examples/local_file_picker/local_file_picker.py"""

    def __init__(self,
                 directory: str,
                 *,
                 upper_limit: str = None,
                 show_hidden_files: bool = False) -> None:
        """Local File save dialog

        This is a simple file save dialog that allows you to save a file to the local filesystem where NiceGUI is running.

        :param directory: The directory to start in.
        :param upper_limit: The directory to stop at (None: no limit, default: same as the starting directory).
        :param show_hidden_files: Whether to show hidden files.
        """
        super().__init__()
        self._selected_drive = None
        # If on a Windows platform attempt to separate the drive and the directory
        if platform.system() == 'Windows' and directory and len(directory) >= 2:
            if directory[0].isalpha() and directory[1] == ':':
                self._selected_drive = directory[:2]
                directory = directory[2:]

        self.path = Path(directory).expanduser()
        if upper_limit is None:
            self.upper_limit = None
        else:
            self.upper_limit = Path(directory if upper_limit == ... else upper_limit).expanduser()
        self.show_hidden_files = show_hidden_files

        with self, ui.card().style('overflow-x: auto; max-width: 100%;'):
            self.add_drives_toggle()
            self.grid = ui.aggrid({
                'columnDefs': [{'field': 'name', 'headerName': 'File'}],
                'rowSelection': 'single',
            }, html_columns=[0]).style('min-width: 600px')
            self.grid.on('cellDoubleClicked', self.handle_double_click)
            with ui.row().classes('w-full justify-end'):

                self._save_filename_input = ui.input("Filename").style('width: 400px;')
                save_button = ui.button('Save').props('outline')
                save_button.on('click', self._save)
                ui.button('Cancel', on_click=self._cancel).props('outline')

        self.update_grid()

    async def select_file(self):
        self.open()
        return await self

    async def _save(self):
        if self._save_filename_input.value:
            _file = Path(self.path, self._save_filename_input.value)
            if _file.exists() and not hasattr(self, '_overwrite_confirmed'):
                self._overwrite_confirmed = True  # flag to skip on next click
                ui.notify(f'"{_file}" already exists. Click Save again to overwrite.', type='warning')
                return

            self.submit([_file])

        else:
            ui.notify('No filename has been entered.', type='negative')

    async def PJAOLD_save(self):
        if self._save_filename_input.value:
            _file = os.path.join(self.path, self._save_filename_input.value)
            self.submit([_file])

        else:
            ui.notify('No filename has been entered.', type='negative')

    def _cancel(self):
        self.close()

    def add_drives_toggle(self):
        if platform.system() == 'Windows':
            import win32api
            drives = win32api.GetLogicalDriveStrings().split('\000')[:-1]
            drive = drives[0]
            # If the caller passed a drive letter select this drive
            if self._selected_drive:
                for drive in drives:
                    if drive.startswith(self._selected_drive):
                        break
            self.drives_toggle = ui.toggle(drives, value=drive, on_change=self.update_drive)

        # Display the current path
        self._path_label = ui.label(str(self.path))

    def update_drive(self):
        self.path = Path(self.drives_toggle.value).expanduser()
        self.update_grid()

    def update_grid(self) -> None:
        paths = list(self.path.glob('*'))
        if not self.show_hidden_files:
            paths = [p for p in paths if not p.name.startswith('.')]
        paths.sort(key=lambda p: p.name.lower())
        paths.sort(key=lambda p: not p.is_dir())

        self.grid.options['rowData'] = [
            {
                'name': f'📁 <strong>{p.name}</strong>' if p.is_dir() else p.name,
                'path': str(p),
            }
            for p in paths
        ]
        if (self.upper_limit is None and self.path != self.path.parent) or \
                (self.upper_limit is not None and self.path != self.upper_limit):
            self.grid.options['rowData'].insert(0, {
                'name': '📁 <strong>..</strong>',
                'path': str(self.path.parent),
            })
        self.grid.update()

    def handle_double_click(self, e) -> None:
        _path = Path(e.args['data']['path'])

        if _path.is_dir():
            self.path = _path
            # Update the displayed path
            self._path_label.set_text(str(self.path))
            self.update_grid()

        else:
            self._save_filename_input.value = _path.name
            # Update the displayed path
            self._path_label.set_text(str(_path.parent))

async def ok_button():
    lfs = local_file_save('c:\\Users\\pja')
    result = await lfs.select_file()
    print(f"PJA: result = {result}")

from nicegui import ui

ui.button('Open Dialog', on_click=ok_button)

ui.run()